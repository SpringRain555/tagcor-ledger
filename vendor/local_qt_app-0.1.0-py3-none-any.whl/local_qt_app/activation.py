"""Wake an existing window over a local Qt socket.

The advisory file lock decides which process is first before Qt starts. This
local socket only asks an already-running process to show its window; it never
replaces the lock. A hash keeps paths, separators, and non-ASCII characters
out of the operating-system channel name, while lowercasing keeps Windows path
spellings equivalent.
"""

from __future__ import annotations

import hashlib
import logging
import sys
from collections.abc import Callable
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import QWidget

ACTIVATE_COMMAND = b"activate"
ACKNOWLEDGED = b"ok"
DEFAULT_TIMEOUT_MS = 1500


def _get_logger(logger: logging.Logger | None) -> logging.Logger:
    if logger is not None:
        return logger
    return logging.getLogger("local_qt_app.activation")


def channel_name(prefix: str, directory: Path) -> str:
    """Return a stable channel name for a resolved directory and caller prefix."""
    resolved = str(directory.resolve()).lower()
    digest = hashlib.sha1(resolved.encode("utf-8")).hexdigest()[:16]
    return f"{prefix}{digest}"


def bring_to_front(window: QWidget) -> None:
    """Restore, raise, and activate the window because each fixes a different state."""
    state = window.windowState()
    window.setWindowState(
        (state & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive
    )
    window.show()
    window.raise_()
    window.activateWindow()


class ActivationServer:
    """Listen for activation requests and handle them in the Qt event loop."""

    def __init__(
        self,
        prefix: str,
        directory: Path,
        on_activate: Callable[[], None],
        *,
        logger: logging.Logger | None = None,
    ) -> None:
        self._name = channel_name(prefix, directory)
        self._on_activate = on_activate
        self._logger = _get_logger(logger)
        self._server: QLocalServer | None = None

    def start(self) -> bool:
        """Remove a stale endpoint, then listen and log failures.

        The caller should already own the single-instance lock before removing
        an endpoint, so a live server cannot be mistaken for a stale one.
        """
        QLocalServer.removeServer(self._name)
        server = QLocalServer()
        if not server.listen(self._name):
            self._logger.warning(
                "activation server unavailable reason=%s", server.errorString()
            )
            return False
        server.newConnection.connect(self._handle_connection)
        self._server = server
        self._logger.info("activation server listening")
        return True

    def close(self) -> None:
        """Close the local endpoint when the owning application exits."""
        if self._server is not None:
            self._server.close()
            self._server = None

    def _handle_connection(self) -> None:
        if self._server is None:
            return
        connection = self._server.nextPendingConnection()
        if connection is None:
            return

        def on_ready() -> None:
            payload = bytes(connection.readAll().data())
            if ACTIVATE_COMMAND not in payload:
                connection.disconnectFromServer()
                return
            connection.write(ACKNOWLEDGED)
            connection.flush()
            self._logger.info("activation requested by another process")
            try:
                self._on_activate()
            finally:
                connection.disconnectFromServer()

        connection.readyRead.connect(on_ready)


def request_activation(
    prefix: str,
    directory: Path,
    *,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
    logger: logging.Logger | None = None,
) -> bool:
    """Ask the running process to activate and wait for its acknowledgement.

    Blocking socket waits also work before a QApplication is created, which
    lets a second launch hand off before constructing its own window. Waiting
    for ``ok`` distinguishes a handled request from bytes merely sent; failure
    lets the caller choose its fallback.

    Each of the three waits (connect, write, reply) gets the full
    ``timeout_ms`` on its own. That is the behavior the applications had before
    this package existed; extracting the code was not the place to tighten it,
    because a briefly busy first instance answering late would turn into an
    "already running" error for the user.
    """
    _allow_foreground_handoff(_get_logger(logger))
    socket = QLocalSocket()
    socket.connectToServer(channel_name(prefix, directory))
    if not socket.waitForConnected(timeout_ms):
        return False
    try:
        socket.write(ACTIVATE_COMMAND)
        if not socket.waitForBytesWritten(timeout_ms):
            return False
        if not socket.waitForReadyRead(timeout_ms):
            return False
        return ACKNOWLEDGED in bytes(socket.readAll().data())
    finally:
        socket.disconnectFromServer()


def _allow_foreground_handoff(logger: logging.Logger) -> None:
    """Let the existing window take focus after a user-initiated second launch.

    Windows normally blocks background focus changes to prevent pop-ups. A
    failed handoff is logged but must not prevent startup.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.user32.AllowSetForegroundWindow(-1)  # ASFW_ANY
    except Exception as exc:  # noqa: BLE001 - focus permission must not block launch
        logger.debug("AllowSetForegroundWindow failed: %s", exc)
