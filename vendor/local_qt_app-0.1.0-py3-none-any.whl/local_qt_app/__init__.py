"""Shared startup mechanisms for local Qt applications."""

__version__ = "0.1.0"
