"""Cross-process single-instance locking without importing Qt.

The file itself can remain after a process is killed. The operating system owns
the advisory lock, so the next process can still acquire it without asking a
person to remove a stale file. A short nonzero timeout also absorbs the small
delay some operating systems need to release a lock during shutdown.

The caller chooses the directory and file name so separate data locations can
run independently. A timeout means another process owns the lock; an I/O error
means the lock storage is unavailable and must not be mistaken for that case.
"""

from __future__ import annotations

from pathlib import Path

from filelock import BaseFileLock, FileLock, Timeout


class AlreadyRunningError(RuntimeError):
    """The requested lock is held by another process."""


class LockUnavailableError(OSError):
    """The lock directory or lock file could not be used."""

    def __init__(self, path: Path) -> None:
        self.path = path
        super().__init__(f"Unable to create or open lock file {path}")


class SingleInstanceGuard:
    """Acquire a caller-named lock and release it as a context manager.

    Keeping the path policy with the caller avoids imposing one global lock on
    applications that intentionally use different data directories.
    """

    def __init__(
        self,
        directory: Path,
        *,
        lock_name: str,
        timeout: float = 0.5,
    ) -> None:
        self.lock_path = directory / lock_name
        self._timeout = timeout
        self._lock: BaseFileLock | None = None

    def acquire(self) -> None:
        """Create the parent and acquire the lock, preserving timeout vs I/O errors."""
        try:
            self.lock_path.parent.mkdir(parents=True, exist_ok=True)
            lock = FileLock(str(self.lock_path), timeout=self._timeout)
            lock.acquire()
        except Timeout as exc:
            raise AlreadyRunningError("ALREADY_RUNNING") from exc
        except OSError as exc:
            raise LockUnavailableError(self.lock_path) from exc
        self._lock = lock

    def release(self) -> None:
        """Release the held lock; repeated calls are harmless."""
        if self._lock is not None:
            self._lock.release()
            self._lock = None

    def __enter__(self) -> "SingleInstanceGuard":  # noqa: UP037
        self.acquire()
        return self

    def __exit__(self, *exc: object) -> None:
        self.release()
