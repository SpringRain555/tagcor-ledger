"""Write and clear a startup-ready marker without importing Qt.

The marker is a small, explicit signal between a launcher and its child
process. Its PID and timestamp make a leftover file diagnosable. Marker I/O is
best-effort because a temporary filesystem problem must not prevent the UI
from opening.
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

MARKER_FILE_NAME = "ui-ready.txt"


def marker_path(directory: Path) -> Path:
    """Return the marker path without creating its parent directory."""
    return directory / MARKER_FILE_NAME


def clear(path: Path) -> bool:
    """Remove a stale marker; return false only when filesystem I/O fails."""
    try:
        path.unlink(missing_ok=True)
    except OSError:
        return False
    return True


def mark_ready(path: Path) -> bool:
    """Write process identity and time after the window is shown.

    The marker tells the launcher that the UI is visible, not merely that
    initialization reached this line. Parent directories are created as
    needed, and an I/O failure stays best-effort so startup can continue.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            f"pid={os.getpid()}\nat={datetime.now().isoformat(timespec='seconds')}\n",
            encoding="utf-8",
        )
    except OSError:
        return False
    return True
